# ------------------------------------------------------------------------------------------ #
# Title: Assignment06
# Desc: This assignment demonstrates using functions
# with structured error handling
# Change Log: (Who, When, What)
#   RRoot,11/21/2023,Created Script
# ------------------------------------------------------------------------------------------ #
import json

# Define the Data Constants
MENU: str = '''
---- Course Registration Program ----
  Select from the following menu:  
    1. Register a Student for a Course.
    2. Show current data.  
    3. Save data to a file.
    4. Exit the program.
----------------------------------------- 
'''
FILE_NAME: str = "Enrollments.json"

# Define the Data Variables
students: list = []  # a table of student data
menu_choice: str  # Hold the choice made by the user.

# Class definitions
class FileProcessor():
    '''
    Handles read/wright
    ChangeLog: (Who, When, What)
    jmalick,11.21.2023,Created Class
    '''

    @staticmethod
    def read_data_from_file(file_name: str):
        '''
        This function opens a json file and returnes it's content as a list
        :param file_name:
        :return list:
        ChangeLog: (Who, When, What)
        jmalick,11.21.2023,Created function
        '''
        file_data: list = [] #local, holds file data
        file = None  # Holds a reference to an opened file.
        try:
            file = open(file_name, "r")
            file_data = json.load(file)
            file.close()
        except Exception as e:
            print("Error: There was a problem with reading the file.")
            print("Please check that the file exists and that it is in a json format.")
            print("-- Technical Error Message -- ")
            print(e.__doc__)
            print(e.__str__())
        finally:
            if file.closed == False:
                file.close()
        return file_data

    @staticmethod
    def write_data_to_file(file_name: str, student_data: list):
        '''
        This function opens a file and wrights the contents of the list being passed in
        :param file_name:
        :param student_data:
        :return nune:
        ChangeLog: (Who, When, What)
        jmalick,11.21.2023,Created function
        '''
        file = None  # Holds a reference to an opened file.
        try:
            file = open(FILE_NAME, "w")
            json.dump(student_data, file)
            file.close()
            raise Exception("Error: There was a problem with writing to the file.")
        except Exception as e:
            if file.closed == False:
                file.close()
            IO.output_error_messages(e.__str__())

class IO ():
    '''
    Handles all user input and output
    ChangeLog: (Who, When, What)
    jmalick,11.21.2023,Created class
    '''
    @staticmethod
    def output_menu(menu: str):
        '''
        Output Menu
        :param string:
        :return none:
        ChangeLog: (Who, When, What)
        jmalick,11.21.2023,Created function
        '''
        print(MENU)

    @staticmethod
    def input_menu_choice ():
        '''
        Gets user input as a string (options ar 1,2,3,4)
        :return string:
        ChangeLog: (Who, When, What)
        jmalick,11.21.2023,Created function
        '''
        choice: str = ''
        try:
            choice = input("Enter your menu choice: ")
            if choice not in ("1", "2", "3", "4"):  # Note these are strings
                raise Exception("You must choose 1, 2, 3, or 4")
        except Exception as e:
            IO.output_error_messages(e.__str__())  # Not passing the exception object to avoid the technical message

        return choice

    @staticmethod
    def output_error_messages(message: str, error: Exception = None):
        '''
        displays the a custom error messages to the user
        :param message:
        :param error:
        :return none:
        ChangeLog: (Who, When, What)
        jmalick,11.21.2023,Created function
        '''
        print(message, end="\n\n")
        if error is not None:
            print("-- Technical Error Message -- ")
            print(error, error.__doc__, type(error), sep='\n')

    @staticmethod
    def output_student_courses(student_data: list):
        '''
        displays the current list of students to the user
        :param student_data:
        :return none:
        ChangeLog: (Who, When, What)
        jmalick,11.21.2023,Created function
        '''
        print("-" * 50)
        for student in student_data:
            print(f'Student {student["FirstName"]} '
                  f'{student["LastName"]} is enrolled in {student["CourseName"]}')
        print("-" * 50)

    @staticmethod
    def input_student_data(student_data: list):
        '''
        Collects registartaion data from user (first name, last name, course name)
        :param student_data:
        :return none:
        ChangeLog: (Who, When, What)
        jmalick,11.21.2023,Created function
        '''
        student_first_name: str = ''  # Holds the first name of a student entered by the user.
        student_last_name: str = ''  # Holds the last name of a student entered by the user.
        course_name: str = ''  # Holds the name of a course entered by the user.
        try:
            student_first_name = input("Enter the student's first name: ")
            if not student_first_name.isalpha():
                raise Exception("The fast name should not contain numbers.")
            student_last_name = input("Enter the student's last name: ")
            if not student_last_name.isalpha():
                raise Exception("The last name should not contain numbers.")
            course_name = input("Please enter the name of the course: ")
            student_data = {"FirstName": student_first_name,
                            "LastName": student_last_name,
                            "CourseName": course_name}
            students.append(student_data)
            print(f"You have registered {student_first_name} {student_last_name} for {course_name}.")
        except Exception as e:
            IO.output_error_messages(e.__str__())

    @staticmethod
    def end_program_msg():
        '''
        Prinst end program message to user
        :return none:
        ChangeLog: (Who, When, What)
        jmalick,11.21.2023,Created function
        '''
        print("Program Ended")


# --- Main ---
# get data from file
students = FileProcessor.read_data_from_file(file_name=FILE_NAME)
while (True):
    # Present the menu of choices
    IO.output_menu(menu=MENU)
    # get choice form user
    menu_choice = IO.input_menu_choice()
    # Input user data
    if menu_choice == "1":  # This will not work if it is an integer!
        IO.input_student_data(student_data=students)
    # Present the current data
    elif menu_choice == "2":
        IO.output_student_courses(student_data=students)
    # Save the data to a file
    elif menu_choice == "3":
        FileProcessor.write_data_to_file(file_name=FILE_NAME, student_data=students)
    # Stop the loop
    elif menu_choice == "4":
        break  # out of the loop
# show user end program msg
IO.end_program_msg()
